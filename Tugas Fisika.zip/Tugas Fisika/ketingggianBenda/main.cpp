#include <iostream>

using namespace std;

double tinggiWaktuTertentu (double a, double b, double c) {
    return (a * b) + (0.5 * c * b * b);
}

int main()
{
    double vNol, t, g;
    cout << "Menghitung Ketinggian Benda Setelah t Detik Jatuh " << endl;
    cout << "h = Vo t + 1/2 gt^2" << endl;
    cout << "Masukkan Kecepatan Awal : ";
    cin >> vNol;
    cout << endl;
    cout << "Masukkan Waktu : ";
    cin >> t;
    cout << "Masukkan Percepatan Gravitasi : ";
    cin >> g;
    cout << "\t h = Vo t + 1/2 gt^2 " << endl;
    cout << "\t h = " << vNol << " x " << t << " + " << "1/2 " << g << " x " << t << "^2" << endl;
    cout << "\t hasil : " << tinggiWaktuTertentu(vNol, t, g);
    return 0;
}
